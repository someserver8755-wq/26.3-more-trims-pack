
$data modify storage new_trims:trimable_materials Slot set value $(Slot)
$data modify storage new_trims:trimable_materials material set from entity @s Inventory[{Slot:$(Slot)b}].id
function new_trims:remove_prefix with storage new_trims:trimable_materials
function new_trims:modify_trim_slot with storage new_trims:trimable_materials

