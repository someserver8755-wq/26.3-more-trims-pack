
$data modify entity @s equipment.head.components."minecraft:trim".material set value "$(material)"
$data modify entity @s equipment.chest.components."minecraft:trim".material set value "$(material)"
$data modify entity @s equipment.legs.components."minecraft:trim".material set value "$(material)"
$data modify entity @s equipment.feet.components."minecraft:trim".material set value "$(material)"

