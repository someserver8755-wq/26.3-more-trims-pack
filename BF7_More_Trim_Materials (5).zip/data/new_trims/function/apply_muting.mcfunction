
data modify storage new_trims:armor_data head_pattern set value "minecraft:shaper"
data modify storage new_trims:armor_data head_material set value "minecraft:quartz"
data modify storage new_trims:armor_data chest_pattern set value "minecraft:shaper"
data modify storage new_trims:armor_data chest_material set value "minecraft:quartz"
data modify storage new_trims:armor_data legs_pattern set value "minecraft:shaper"
data modify storage new_trims:armor_data legs_material set value "minecraft:quartz"
data modify storage new_trims:armor_data feet_pattern set value "minecraft:shaper"
data modify storage new_trims:armor_data feet_material set value "minecraft:quartz"


execute if items entity @s armor.head *[trim] run data modify storage new_trims:armor_data head_pattern set from entity @s equipment.head.components."minecraft:trim".pattern
execute if items entity @s armor.head *[trim] run data modify storage new_trims:armor_data head_material set from entity @s equipment.head.components."minecraft:trim".material
execute if items entity @s armor.chest *[trim] run data modify storage new_trims:armor_data chest_pattern set from entity @s equipment.chest.components."minecraft:trim".pattern
execute if items entity @s armor.chest *[trim] run data modify storage new_trims:armor_data chest_material set from entity @s equipment.chest.components."minecraft:trim".material
execute if items entity @s armor.legs *[trim] run data modify storage new_trims:armor_data legs_pattern set from entity @s equipment.legs.components."minecraft:trim".pattern
execute if items entity @s armor.legs *[trim] run data modify storage new_trims:armor_data legs_material set from entity @s equipment.legs.components."minecraft:trim".material
execute if items entity @s armor.feet *[trim] run data modify storage new_trims:armor_data feet_pattern set from entity @s equipment.feet.components."minecraft:trim".pattern
execute if items entity @s armor.feet *[trim] run data modify storage new_trims:armor_data feet_material set from entity @s equipment.feet.components."minecraft:trim".material

function new_trims:remove_glow with storage new_trims:armor_data
function new_trims:modify_trim_aspects with storage new_trims:armor_data

advancement revoke @s only new_trims:apply_muting

