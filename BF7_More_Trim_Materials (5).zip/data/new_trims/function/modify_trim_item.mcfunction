
$execute if items entity @s contents #new_trims:new_trim_materials[!custom_data~{trimable:true}] run data modify entity @s Item.components."minecraft:provides_trim_material" set value "new_trims:$(material)"
execute if items entity @s contents #new_trims:new_trim_materials[!custom_data~{trimable:true}] run data modify entity @s Item.components."minecraft:custom_data".trimable set value true
