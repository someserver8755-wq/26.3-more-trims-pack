
$execute if items entity @s container.$(Slot) #new_trims:new_trim_materials[!custom_data~{trimable:true}] run item modify entity @s container.$(Slot) [{type:"set_components",components:{"custom_data":{trimable:true},"provides_trim_material":"new_trims:$(material)"}}]

