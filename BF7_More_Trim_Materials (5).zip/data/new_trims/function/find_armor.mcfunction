
$data modify storage new_trims:armor_values helmet_type set from storage new_trims:trim_list armor.head[$(helmet_type)]
$data modify storage new_trims:armor_values helmet_pattern set from storage new_trims:trim_list patterns[$(helmet_pattern)]
$data modify storage new_trims:armor_values helmet_material set from storage new_trims:trim_list materials[$(helmet_material)]

$data modify storage new_trims:armor_values chestplate_type set from storage new_trims:trim_list armor.chest[$(chestplate_type)]
$data modify storage new_trims:armor_values chestplate_pattern set from storage new_trims:trim_list patterns[$(chestplate_pattern)]
$data modify storage new_trims:armor_values chestplate_material set from storage new_trims:trim_list materials[$(chestplate_material)]

$data modify storage new_trims:armor_values leggings_type set from storage new_trims:trim_list armor.legs[$(leggings_type)]
$data modify storage new_trims:armor_values leggings_pattern set from storage new_trims:trim_list patterns[$(leggings_pattern)]
$data modify storage new_trims:armor_values leggings_material set from storage new_trims:trim_list materials[$(leggings_material)]

$data modify storage new_trims:armor_values boots_type set from storage new_trims:trim_list armor.feet[$(boots_type)]
$data modify storage new_trims:armor_values boots_pattern set from storage new_trims:trim_list patterns[$(boots_pattern)]
$data modify storage new_trims:armor_values boots_material set from storage new_trims:trim_list materials[$(boots_material)]

function new_trims:give_specific_armor with storage new_trims:armor_values

