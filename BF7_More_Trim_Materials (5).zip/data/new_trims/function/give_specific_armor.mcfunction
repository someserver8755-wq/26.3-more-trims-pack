
$item replace entity @s armor.head with $(helmet_type)[trim={pattern:"$(helmet_pattern)",material:"$(helmet_material)_glow"}]
$item replace entity @s armor.chest with $(chestplate_type)[trim={pattern:"$(chestplate_pattern)",material:"$(chestplate_material)_glow"}]
$item replace entity @s armor.legs with $(leggings_type)[trim={pattern:"$(leggings_pattern)",material:"$(leggings_material)_glow"}]
$item replace entity @s armor.feet with $(boots_type)[trim={pattern:"$(boots_pattern)",material:"$(boots_material)_glow"}]

