
$data modify storage new_trims:trimable_materials material set from storage new_trims:trim_string_data material_strings[{input:"$(material)"}].output

