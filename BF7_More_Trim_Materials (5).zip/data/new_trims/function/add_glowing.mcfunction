
$data modify storage new_trims:armor_data head_material set from storage new_trims:trim_string_data add_glowing[{input:"$(head_material)"}].output
$data modify storage new_trims:armor_data chest_material set from storage new_trims:trim_string_data add_glowing[{input:"$(chest_material)"}].output
$data modify storage new_trims:armor_data legs_material set from storage new_trims:trim_string_data add_glowing[{input:"$(legs_material)"}].output
$data modify storage new_trims:armor_data feet_material set from storage new_trims:trim_string_data add_glowing[{input:"$(feet_material)"}].output

