
data modify storage new_trims:trimable_materials material set from entity @s Item.id
function new_trims:remove_prefix with storage new_trims:trimable_materials
function new_trims:modify_trim_item with storage new_trims:trimable_materials

