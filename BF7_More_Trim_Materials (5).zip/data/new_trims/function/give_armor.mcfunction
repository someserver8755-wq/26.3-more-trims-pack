$item replace entity @s hotbar.0 with minecraft:$(armor)_helmet[trim={pattern:"$(pattern)",material:"$(material)"}]
$item replace entity @s hotbar.1 with minecraft:$(armor)_chestplate[trim={pattern:"$(pattern)",material:"$(material)"}]
$item replace entity @s hotbar.2 with minecraft:$(armor)_leggings[trim={pattern:"$(pattern)",material:"$(material)"}]
$item replace entity @s hotbar.3 with minecraft:$(armor)_boots[trim={pattern:"$(pattern)",material:"$(material)"}]