
$execute if items entity @s armor.head *[trim] run item modify entity @s armor.head {"type":"minecraft:set_components","components":{"minecraft:trim":{"material":"$(head_material)","pattern":"$(head_pattern)"}}}
$execute if items entity @s armor.chest *[trim] run item modify entity @s armor.chest {"type":"minecraft:set_components","components":{"minecraft:trim":{"material":"$(chest_material)","pattern":"$(chest_pattern)"}}}
$execute if items entity @s armor.legs *[trim] run item modify entity @s armor.legs {"type":"minecraft:set_components","components":{"minecraft:trim":{"material":"$(legs_material)","pattern":"$(legs_pattern)"}}}
$execute if items entity @s armor.feet *[trim] run item modify entity @s armor.feet {"type":"minecraft:set_components","components":{"minecraft:trim":{"material":"$(feet_material)","pattern":"$(feet_pattern)"}}}

