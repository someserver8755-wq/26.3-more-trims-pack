
data modify storage new_trims:trim_string_data add_glowing set value [ \
	{input:"minecraft:quartz", output:"new_trims:quartz_glow"}, \
	{input:"minecraft:iron", output:"new_trims:iron_glow"}, \
	{input:"minecraft:netherite", output:"new_trims:netherite_glow"}, \
	{input:"minecraft:redstone", output:"new_trims:redstone_glow"}, \
	{input:"minecraft:copper", output:"new_trims:copper_glow"}, \
	{input:"minecraft:gold", output:"new_trims:gold_glow"}, \
	{input:"minecraft:emerald", output:"new_trims:emerald_glow"}, \
	{input:"minecraft:diamond", output:"new_trims:diamond_glow"}, \
	{input:"minecraft:lapis", output:"new_trims:lapis_glow"}, \
	{input:"minecraft:amethyst", output:"new_trims:amethyst_glow"}, \
	{input:"minecraft:resin", output:"new_trims:resin_glow"}, \
	{input:"new_trims:white_dye", output:"new_trims:white_dye_glow"}, \
	{input:"new_trims:light_gray_dye", output:"new_trims:light_gray_dye_glow"}, \
	{input:"new_trims:gray_dye", output:"new_trims:gray_dye_glow"}, \
	{input:"new_trims:black_dye", output:"new_trims:black_dye_glow"}, \
	{input:"new_trims:brown_dye", output:"new_trims:brown_dye_glow"}, \
	{input:"new_trims:red_dye", output:"new_trims:red_dye_glow"}, \
	{input:"new_trims:orange_dye", output:"new_trims:orange_dye_glow"}, \
	{input:"new_trims:yellow_dye", output:"new_trims:yellow_dye_glow"}, \
	{input:"new_trims:lime_dye", output:"new_trims:lime_dye_glow"}, \
	{input:"new_trims:green_dye", output:"new_trims:green_dye_glow"}, \
	{input:"new_trims:cyan_dye", output:"new_trims:cyan_dye_glow"}, \
	{input:"new_trims:light_blue_dye", output:"new_trims:light_blue_dye_glow"}, \
	{input:"new_trims:blue_dye", output:"new_trims:blue_dye_glow"}, \
	{input:"new_trims:purple_dye", output:"new_trims:purple_dye_glow"}, \
	{input:"new_trims:magenta_dye", output:"new_trims:magenta_dye_glow"}, \
	{input:"new_trims:pink_dye", output:"new_trims:pink_dye_glow"}, \
	{input:"new_trims:nether_star", output:"new_trims:nether_star_glow"}, \
	{input:"new_trims:sugar", output:"new_trims:sugar_glow"}, \
	{input:"new_trims:bone_block", output:"new_trims:bone_block_glow"}, \
	{input:"new_trims:ghast_tear", output:"new_trims:ghast_tear_glow"}, \
	{input:"new_trims:clay_ball", output:"new_trims:clay_ball_glow"}, \
	{input:"new_trims:heavy_core", output:"new_trims:heavy_core_glow"}, \
	{input:"new_trims:gunpowder", output:"new_trims:gunpowder_glow"}, \
	{input:"new_trims:creaking_heart", output:"new_trims:creaking_heart_glow"}, \
	{input:"new_trims:coal", output:"new_trims:coal_glow"}, \
	{input:"new_trims:netherite_scrap", output:"new_trims:netherite_scrap_glow"}, \
	{input:"new_trims:nautilus_shell", output:"new_trims:nautilus_shell_glow"}, \
	{input:"new_trims:leather", output:"new_trims:leather_glow"}, \
	{input:"new_trims:nether_wart_block", output:"new_trims:nether_wart_block_glow"}, \
	{input:"new_trims:nether_brick", output:"new_trims:nether_brick_glow"}, \
	{input:"new_trims:magma_block", output:"new_trims:magma_block_glow"}, \
	{input:"new_trims:ochre_froglight", output:"new_trims:ochre_froglight_glow"}, \
	{input:"new_trims:glowstone_dust", output:"new_trims:glowstone_dust_glow"}, \
	{input:"new_trims:blaze_rod", output:"new_trims:blaze_rod_glow"}, \
	{input:"new_trims:slime_ball", output:"new_trims:slime_ball_glow"}, \
	{input:"new_trims:moss_block", output:"new_trims:moss_block_glow"}, \
	{input:"new_trims:ender_eye", output:"new_trims:ender_eye_glow"}, \
	{input:"new_trims:verdant_froglight", output:"new_trims:verdant_froglight_glow"}, \
	{input:"new_trims:turtle_scute", output:"new_trims:turtle_scute_glow"}, \
	{input:"new_trims:dried_kelp_block", output:"new_trims:dried_kelp_block_glow"}, \
	{input:"new_trims:ender_pearl", output:"new_trims:ender_pearl_glow"}, \
	{input:"new_trims:heart_of_the_sea", output:"new_trims:heart_of_the_sea_glow"}, \
	{input:"new_trims:warped_wart_block", output:"new_trims:warped_wart_block_glow"}, \
	{input:"new_trims:prismarine_shard", output:"new_trims:prismarine_shard_glow"}, \
	{input:"new_trims:prismarine_crystals", output:"new_trims:prismarine_crystals_glow"}, \
	{input:"new_trims:breeze_rod", output:"new_trims:breeze_rod_glow"}, \
	{input:"new_trims:blue_ice", output:"new_trims:blue_ice_glow"}, \
	{input:"new_trims:echo_shard", output:"new_trims:echo_shard_glow"}, \
	{input:"new_trims:sculk", output:"new_trims:sculk_glow"}, \
	{input:"new_trims:obsidian", output:"new_trims:obsidian_glow"}, \
	{input:"new_trims:crying_obsidian", output:"new_trims:crying_obsidian_glow"}, \
	{input:"new_trims:pearlescent_froglight", output:"new_trims:pearlescent_froglight_glow"}, \
	{input:"new_trims:shulker_shell", output:"new_trims:shulker_shell_glow"}, \
	{input:"new_trims:popped_chorus_fruit", output:"new_trims:popped_chorus_fruit_glow"}, \
	{input:"new_trims:dragon_breath", output:"new_trims:dragon_breath_glow"}, \
	{input:"new_trims:armadillo_scute", output:"new_trims:armadillo_scute_glow"}, \
	{input:"new_trims:cactus_flower", output:"new_trims:cactus_flower_glow"}, \
	{input:"new_trims:bomber", output:"new_trims:bomber_glow"}, \
	{input:"new_trims:sxlar", output:"new_trims:sxlar_glow"}, \
	{input:"new_trims:cake", output:"new_trims:cake_glow"}, \
	{input:"new_trims:tnt", output:"new_trims:tnt_glow"}, \
	{input:"new_trims:creeper_head", output:"new_trims:creeper_head_glow"}, \
	{input:"new_trims:glow_berries", output:"new_trims:glow_berries_glow"}, \
	{input:"new_trims:melon", output:"new_trims:melon_glow"}, \
	{input:"new_trims:melon_slice", output:"new_trims:melon_slice_glow"}, \
	{input:"new_trims:pumpkin", output:"new_trims:pumpkin_glow"}, \
	{input:"new_trims:pufferfish", output:"new_trims:pufferfish_glow"}, \
	{input:"new_trims:shroomlight", output:"new_trims:shroomlight_glow"}, \
	{input:"new_trims:pitcher_plant", output:"new_trims:pitcher_plant_glow"}, \
	{input:"new_trims:torchflower", output:"new_trims:torchflower_glow"}, \
	{input:"new_trims:torchflower_ass", output:"new_trims:torchflower_ass_glow"}, \
	{input:"new_trims:tropical_fish", output:"new_trims:tropical_fish_glow"}, \
	{input:"new_trims:chorus_flower", output:"new_trims:chorus_flower_glow"}, \
	{input:"new_trims:end_crystal", output:"new_trims:end_crystal_glow"}, \
	{input:"new_trims:spore_blossom", output:"new_trims:spore_blossom_glow"}, \
	{input:"new_trims:pink_petals", output:"new_trims:pink_petals_glow"}, \
	{input:"new_trims:red_mushroom_block", output:"new_trims:red_mushroom_block_glow"}, \
	{input:"new_trims:brown_mushroom_block", output:"new_trims:brown_mushroom_block_glow"}, \
	{input:"new_trims:apple", output:"new_trims:apple_glow"}, \
	{input:"new_trims:fermented_spider_eye", output:"new_trims:fermented_spider_eye_glow"}, \
	{input:"new_trims:salmon", output:"new_trims:salmon_glow"}, \
	{input:"new_trims:cod", output:"new_trims:cod_glow"}, \
	{input:"new_trims:beetroot", output:"new_trims:beetroot_glow"}, \
	{input:"new_trims:brain_coral", output:"new_trims:brain_coral_glow"}, \
	{input:"new_trims:bubble_coral", output:"new_trims:bubble_coral_glow"}, \
	{input:"new_trims:dark_prismarine", output:"new_trims:dark_prismarine_glow"}, \
	{input:"new_trims:end_stone", output:"new_trims:end_stone_glow"}, \
	{input:"new_trims:experience_bottle", output:"new_trims:experience_bottle_glow"}, \
	{input:"new_trims:fire_coral", output:"new_trims:fire_coral_glow"}, \
	{input:"new_trims:honey_bottle", output:"new_trims:honey_bottle_glow"}, \
	{input:"new_trims:honeycomb", output:"new_trims:honeycomb_glow"}, \
	{input:"new_trims:horn_coral", output:"new_trims:horn_coral_glow"}, \
	{input:"new_trims:pointed_dripstone", output:"new_trims:pointed_dripstone_glow"}, \
	{input:"new_trims:raw_copper", output:"new_trims:raw_copper_glow"}, \
	{input:"new_trims:raw_gold", output:"new_trims:raw_gold_glow"}, \
	{input:"new_trims:raw_iron", output:"new_trims:raw_iron_glow"}, \
	{input:"new_trims:sculk_catalyst", output:"new_trims:sculk_catalyst_glow"}, \
	{input:"new_trims:soul_sand", output:"new_trims:soul_sand_glow"}, \
	{input:"new_trims:tube_coral", output:"new_trims:tube_coral_glow"}, \
	{input:"new_trims:wildflowers", output:"new_trims:wildflowers_glow"}, \
	{input:"new_trims:sniffer_egg", output:"new_trims:sniffer_egg_glow"}, \
	{input:"new_trims:pale_moss_block", output:"new_trims:pale_moss_block_glow"}, \
	{input:"new_trims:mycelium", output:"new_trims:mycelium_glow"}, \
	{input:"new_trims:podzol", output:"new_trims:podzol_glow"}, \
	{input:"new_trims:redstone_lamp", output:"new_trims:redstone_lamp_glow"}, \
	{input:"new_trims:sweet_berries", output:"new_trims:sweet_berries_glow"}, \
	{input:"new_trims:nether_wart", output:"new_trims:nether_wart_glow"}, \
	{input:"new_trims:crimson_fungus", output:"new_trims:crimson_fungus_glow"}, \
	{input:"new_trims:warped_fungus", output:"new_trims:warped_fungus_glow"}, \
	{input:"new_trims:amethyst_cluster", output:"new_trims:amethyst_cluster_glow"}, \
	{input:"new_trims:fire_charge", output:"new_trims:fire_charge_glow"}, \
	{input:"new_trims:brick", output:"new_trims:brick_glow"}, \
	{input:"new_trims:shelf_mushroom", output:"new_trims:shelf_mushroom_glow"}, \
	{input:"new_trims:pumpkin_pie", output:"new_trims:pumpkin_pie_glow"}, \
	{input:"new_trims:lily_pad", output:"new_trims:lily_pad_glow"}, \
	{input:"new_trims:sea_pickle", output:"new_trims:sea_pickle_glow"}, \
	{input:"new_trims:target", output:"new_trims:target_glow"}, \
	{input:"new_trims:phantom_membrane", output:"new_trims:phantom_membrane_glow"} \
]

data modify storage new_trims:trim_string_data remove_glowing set value [ \
	{input:"new_trims:quartz_glow", output:"minecraft:quartz"}, \
	{input:"new_trims:iron_glow", output:"minecraft:iron"}, \
	{input:"new_trims:netherite_glow", output:"minecraft:netherite"}, \
	{input:"new_trims:redstone_glow", output:"minecraft:redstone"}, \
	{input:"new_trims:copper_glow", output:"minecraft:copper"}, \
	{input:"new_trims:gold_glow", output:"minecraft:gold"}, \
	{input:"new_trims:emerald_glow", output:"minecraft:emerald"}, \
	{input:"new_trims:diamond_glow", output:"minecraft:diamond"}, \
	{input:"new_trims:lapis_glow", output:"minecraft:lapis"}, \
	{input:"new_trims:amethyst_glow", output:"minecraft:amethyst"}, \
	{input:"new_trims:resin_glow", output:"minecraft:resin"}, \
	{input:"new_trims:white_dye_glow", output:"new_trims:white_dye"}, \
	{input:"new_trims:light_gray_dye_glow", output:"new_trims:light_gray_dye"}, \
	{input:"new_trims:gray_dye_glow", output:"new_trims:gray_dye"}, \
	{input:"new_trims:black_dye_glow", output:"new_trims:black_dye"}, \
	{input:"new_trims:brown_dye_glow", output:"new_trims:brown_dye"}, \
	{input:"new_trims:red_dye_glow", output:"new_trims:red_dye"}, \
	{input:"new_trims:orange_dye_glow", output:"new_trims:orange_dye"}, \
	{input:"new_trims:yellow_dye_glow", output:"new_trims:yellow_dye"}, \
	{input:"new_trims:lime_dye_glow", output:"new_trims:lime_dye"}, \
	{input:"new_trims:green_dye_glow", output:"new_trims:green_dye"}, \
	{input:"new_trims:cyan_dye_glow", output:"new_trims:cyan_dye"}, \
	{input:"new_trims:light_blue_dye_glow", output:"new_trims:light_blue_dye"}, \
	{input:"new_trims:blue_dye_glow", output:"new_trims:blue_dye"}, \
	{input:"new_trims:purple_dye_glow", output:"new_trims:purple_dye"}, \
	{input:"new_trims:magenta_dye_glow", output:"new_trims:magenta_dye"}, \
	{input:"new_trims:pink_dye_glow", output:"new_trims:pink_dye"}, \
	{input:"new_trims:nether_star_glow", output:"new_trims:nether_star"}, \
	{input:"new_trims:sugar_glow", output:"new_trims:sugar"}, \
	{input:"new_trims:bone_block_glow", output:"new_trims:bone_block"}, \
	{input:"new_trims:ghast_tear_glow", output:"new_trims:ghast_tear"}, \
	{input:"new_trims:clay_ball_glow", output:"new_trims:clay_ball"}, \
	{input:"new_trims:heavy_core_glow", output:"new_trims:heavy_core"}, \
	{input:"new_trims:gunpowder_glow", output:"new_trims:gunpowder"}, \
	{input:"new_trims:creaking_heart_glow", output:"new_trims:creaking_heart"}, \
	{input:"new_trims:coal_glow", output:"new_trims:coal"}, \
	{input:"new_trims:netherite_scrap_glow", output:"new_trims:netherite_scrap"}, \
	{input:"new_trims:nautilus_shell_glow", output:"new_trims:nautilus_shell"}, \
	{input:"new_trims:leather_glow", output:"new_trims:leather"}, \
	{input:"new_trims:nether_wart_block_glow", output:"new_trims:nether_wart_block"}, \
	{input:"new_trims:nether_brick_glow", output:"new_trims:nether_brick"}, \
	{input:"new_trims:magma_block_glow", output:"new_trims:magma_block"}, \
	{input:"new_trims:ochre_froglight_glow", output:"new_trims:ochre_froglight"}, \
	{input:"new_trims:glowstone_dust_glow", output:"new_trims:glowstone_dust"}, \
	{input:"new_trims:blaze_rod_glow", output:"new_trims:blaze_rod"}, \
	{input:"new_trims:slime_ball_glow", output:"new_trims:slime_ball"}, \
	{input:"new_trims:moss_block_glow", output:"new_trims:moss_block"}, \
	{input:"new_trims:ender_eye_glow", output:"new_trims:ender_eye"}, \
	{input:"new_trims:verdant_froglight_glow", output:"new_trims:verdant_froglight"}, \
	{input:"new_trims:turtle_scute_glow", output:"new_trims:turtle_scute"}, \
	{input:"new_trims:dried_kelp_block_glow", output:"new_trims:dried_kelp_block"}, \
	{input:"new_trims:ender_pearl_glow", output:"new_trims:ender_pearl"}, \
	{input:"new_trims:heart_of_the_sea_glow", output:"new_trims:heart_of_the_sea"}, \
	{input:"new_trims:warped_wart_block_glow", output:"new_trims:warped_wart_block"}, \
	{input:"new_trims:prismarine_shard_glow", output:"new_trims:prismarine_shard"}, \
	{input:"new_trims:prismarine_crystals_glow", output:"new_trims:prismarine_crystals"}, \
	{input:"new_trims:breeze_rod_glow", output:"new_trims:breeze_rod"}, \
	{input:"new_trims:blue_ice_glow", output:"new_trims:blue_ice"}, \
	{input:"new_trims:echo_shard_glow", output:"new_trims:echo_shard"}, \
	{input:"new_trims:sculk_glow", output:"new_trims:sculk"}, \
	{input:"new_trims:obsidian_glow", output:"new_trims:obsidian"}, \
	{input:"new_trims:crying_obsidian_glow", output:"new_trims:crying_obsidian"}, \
	{input:"new_trims:pearlescent_froglight_glow", output:"new_trims:pearlescent_froglight"}, \
	{input:"new_trims:shulker_shell_glow", output:"new_trims:shulker_shell"}, \
	{input:"new_trims:popped_chorus_fruit_glow", output:"new_trims:popped_chorus_fruit"}, \
	{input:"new_trims:dragon_breath_glow", output:"new_trims:dragon_breath"}, \
	{input:"new_trims:armadillo_scute_glow", output:"new_trims:armadillo_scute"}, \
	{input:"new_trims:cactus_flower_glow", output:"new_trims:cactus_flower"}, \
	{input:"new_trims:bomber_glow", output:"new_trims:bomber"}, \
	{input:"new_trims:sxlar_glow", output:"new_trims:sxlar"}, \
	{input:"new_trims:cake_glow", output:"new_trims:cake"}, \
	{input:"new_trims:tnt_glow", output:"new_trims:tnt"}, \
	{input:"new_trims:creeper_head_glow", output:"new_trims:creeper_head"}, \
	{input:"new_trims:glow_berries_glow", output:"new_trims:glow_berries"}, \
	{input:"new_trims:melon_glow", output:"new_trims:melon"}, \
	{input:"new_trims:melon_slice_glow", output:"new_trims:melon_slice"}, \
	{input:"new_trims:pumpkin_glow", output:"new_trims:pumpkin"}, \
	{input:"new_trims:pufferfish_glow", output:"new_trims:pufferfish"}, \
	{input:"new_trims:shroomlight_glow", output:"new_trims:shroomlight"}, \
	{input:"new_trims:pitcher_plant_glow", output:"new_trims:pitcher_plant"}, \
	{input:"new_trims:torchflower_glow", output:"new_trims:torchflower"}, \
	{input:"new_trims:torchflower_ass_glow", output:"new_trims:torchflower_ass"}, \
	{input:"new_trims:tropical_fish_glow", output:"new_trims:tropical_fish"}, \
	{input:"new_trims:chorus_flower_glow", output:"new_trims:chorus_flower"}, \
	{input:"new_trims:end_crystal_glow", output:"new_trims:end_crystal"}, \
	{input:"new_trims:spore_blossom_glow", output:"new_trims:spore_blossom"}, \
	{input:"new_trims:pink_petals_glow", output:"new_trims:pink_petals"}, \
	{input:"new_trims:red_mushroom_block_glow", output:"new_trims:red_mushroom_block"}, \
	{input:"new_trims:brown_mushroom_block_glow", output:"new_trims:brown_mushroom_block"}, \
	{input:"new_trims:apple_glow", output:"new_trims:apple"}, \
	{input:"new_trims:fermented_spider_eye_glow", output:"new_trims:fermented_spider_eye"}, \
	{input:"new_trims:salmon_glow", output:"new_trims:salmon"}, \
	{input:"new_trims:cod_glow", output:"new_trims:cod"}, \
	{input:"new_trims:beetroot_glow", output:"new_trims:beetroot"}, \
	{input:"new_trims:brain_coral_glow", output:"new_trims:brain_coral"}, \
	{input:"new_trims:bubble_coral_glow", output:"new_trims:bubble_coral"}, \
	{input:"new_trims:dark_prismarine_glow", output:"new_trims:dark_prismarine"}, \
	{input:"new_trims:end_stone_glow", output:"new_trims:end_stone"}, \
	{input:"new_trims:experience_bottle_glow", output:"new_trims:experience_bottle"}, \
	{input:"new_trims:fire_coral_glow", output:"new_trims:fire_coral"}, \
	{input:"new_trims:honey_bottle_glow", output:"new_trims:honey_bottle"}, \
	{input:"new_trims:honeycomb_glow", output:"new_trims:honeycomb"}, \
	{input:"new_trims:horn_coral_glow", output:"new_trims:horn_coral"}, \
	{input:"new_trims:pointed_dripstone_glow", output:"new_trims:pointed_dripstone"}, \
	{input:"new_trims:raw_copper_glow", output:"new_trims:raw_copper"}, \
	{input:"new_trims:raw_gold_glow", output:"new_trims:raw_gold"}, \
	{input:"new_trims:raw_iron_glow", output:"new_trims:raw_iron"}, \
	{input:"new_trims:sculk_catalyst_glow", output:"new_trims:sculk_catalyst"}, \
	{input:"new_trims:soul_sand_glow", output:"new_trims:soul_sand"}, \
	{input:"new_trims:tube_coral_glow", output:"new_trims:tube_coral"}, \
	{input:"new_trims:wildflowers_glow", output:"new_trims:wildflowers"}, \
	{input:"new_trims:sniffer_egg_glow", output:"new_trims:sniffer_egg"}, \
	{input:"new_trims:pale_moss_block_glow", output:"new_trims:pale_moss_block"}, \
	{input:"new_trims:mycelium_glow", output:"new_trims:mycelium"}, \
	{input:"new_trims:podzol_glow", output:"new_trims:podzol"}, \
	{input:"new_trims:redstone_lamp_glow", output:"new_trims:redstone_lamp"}, \
	{input:"new_trims:sweet_berries_glow", output:"new_trims:sweet_berries"}, \
	{input:"new_trims:nether_wart_glow", output:"new_trims:nether_wart"}, \
	{input:"new_trims:crimson_fungus_glow", output:"new_trims:crimson_fungus"}, \
	{input:"new_trims:warped_fungus_glow", output:"new_trims:warped_fungus"}, \
	{input:"new_trims:amethyst_cluster_glow", output:"new_trims:amethyst_cluster"}, \
	{input:"new_trims:fire_charge_glow", output:"new_trims:fire_charge"}, \
	{input:"new_trims:brick_glow", output:"new_trims:brick"}, \
	{input:"new_trims:shelf_mushroom_glow", output:"new_trims:shelf_mushroom"}, \
	{input:"new_trims:pumpkin_pie_glow", output:"new_trims:pumpkin_pie"}, \
	{input:"new_trims:lily_pad_glow", output:"new_trims:lily_pad"}, \
	{input:"new_trims:sea_pickle_glow", output:"new_trims:sea_pickle"}, \
	{input:"new_trims:target_glow", output:"new_trims:target"}, \
	{input:"new_trims:phantom_membrane_glow", output:"new_trims:phantom_membrane"} \
]


data modify storage new_trims:trim_string_data material_strings set value [ \
	{input:"minecraft:white_dye", output:"white_dye"}, \
	{input:"minecraft:light_gray_dye", output:"light_gray_dye"}, \
	{input:"minecraft:gray_dye", output:"gray_dye"}, \
	{input:"minecraft:black_dye", output:"black_dye"}, \
	{input:"minecraft:brown_dye", output:"brown_dye"}, \
	{input:"minecraft:red_dye", output:"red_dye"}, \
	{input:"minecraft:orange_dye", output:"orange_dye"}, \
	{input:"minecraft:yellow_dye", output:"yellow_dye"}, \
	{input:"minecraft:lime_dye", output:"lime_dye"}, \
	{input:"minecraft:green_dye", output:"green_dye"}, \
	{input:"minecraft:cyan_dye", output:"cyan_dye"}, \
	{input:"minecraft:light_blue_dye", output:"light_blue_dye"}, \
	{input:"minecraft:blue_dye", output:"blue_dye"}, \
	{input:"minecraft:purple_dye", output:"purple_dye"}, \
	{input:"minecraft:magenta_dye", output:"magenta_dye"}, \
	{input:"minecraft:pink_dye", output:"pink_dye"}, \
	{input:"minecraft:nether_star", output:"nether_star"}, \
	{input:"minecraft:sugar", output:"sugar"}, \
	{input:"minecraft:bone_block", output:"bone_block"}, \
	{input:"minecraft:ghast_tear", output:"ghast_tear"}, \
	{input:"minecraft:clay_ball", output:"clay_ball"}, \
	{input:"minecraft:heavy_core", output:"heavy_core"}, \
	{input:"minecraft:gunpowder", output:"gunpowder"}, \
	{input:"minecraft:creaking_heart", output:"creaking_heart"}, \
	{input:"minecraft:coal", output:"coal"}, \
	{input:"minecraft:netherite_scrap", output:"netherite_scrap"}, \
	{input:"minecraft:nautilus_shell", output:"nautilus_shell"}, \
	{input:"minecraft:leather", output:"leather"}, \
	{input:"minecraft:nether_wart_block", output:"nether_wart_block"}, \
	{input:"minecraft:nether_brick", output:"nether_brick"}, \
	{input:"minecraft:magma_block", output:"magma_block"}, \
	{input:"minecraft:ochre_froglight", output:"ochre_froglight"}, \
	{input:"minecraft:glowstone_dust", output:"glowstone_dust"}, \
	{input:"minecraft:blaze_rod", output:"blaze_rod"}, \
	{input:"minecraft:slime_ball", output:"slime_ball"}, \
	{input:"minecraft:moss_block", output:"moss_block"}, \
	{input:"minecraft:ender_eye", output:"ender_eye"}, \
	{input:"minecraft:verdant_froglight", output:"verdant_froglight"}, \
	{input:"minecraft:turtle_scute", output:"turtle_scute"}, \
	{input:"minecraft:dried_kelp_block", output:"dried_kelp_block"}, \
	{input:"minecraft:ender_pearl", output:"ender_pearl"}, \
	{input:"minecraft:heart_of_the_sea", output:"heart_of_the_sea"}, \
	{input:"minecraft:warped_wart_block", output:"warped_wart_block"}, \
	{input:"minecraft:prismarine_shard", output:"prismarine_shard"}, \
	{input:"minecraft:prismarine_crystals", output:"prismarine_crystals"}, \
	{input:"minecraft:breeze_rod", output:"breeze_rod"}, \
	{input:"minecraft:blue_ice", output:"blue_ice"}, \
	{input:"minecraft:echo_shard", output:"echo_shard"}, \
	{input:"minecraft:sculk", output:"sculk"}, \
	{input:"minecraft:obsidian", output:"obsidian"}, \
	{input:"minecraft:crying_obsidian", output:"crying_obsidian"}, \
	{input:"minecraft:pearlescent_froglight", output:"pearlescent_froglight"}, \
	{input:"minecraft:shulker_shell", output:"shulker_shell"}, \
	{input:"minecraft:popped_chorus_fruit", output:"popped_chorus_fruit"}, \
	{input:"minecraft:dragon_breath", output:"dragon_breath"}, \
	{input:"minecraft:armadillo_scute", output:"armadillo_scute"}, \
	{input:"minecraft:cactus_flower", output:"cactus_flower"}, \
	{input:"minecraft:bomber", output:"bomber"}, \
	{input:"minecraft:sxlar", output:"sxlar"}, \
	{input:"minecraft:cake", output:"cake"}, \
	{input:"minecraft:tnt", output:"tnt"}, \
	{input:"minecraft:creeper_head", output:"creeper_head"}, \
	{input:"minecraft:glow_berries", output:"glow_berries"}, \
	{input:"minecraft:melon", output:"melon"}, \
	{input:"minecraft:melon_slice", output:"melon_slice"}, \
	{input:"minecraft:pumpkin", output:"pumpkin"}, \
	{input:"minecraft:pufferfish", output:"pufferfish"}, \
	{input:"minecraft:shroomlight", output:"shroomlight"}, \
	{input:"minecraft:pitcher_plant", output:"pitcher_plant"}, \
	{input:"minecraft:torchflower", output:"torchflower"}, \
	{input:"minecraft:torchflower_ass", output:"torchflower_ass"}, \
	{input:"minecraft:tropical_fish", output:"tropical_fish"}, \
	{input:"minecraft:chorus_flower", output:"chorus_flower"}, \
	{input:"minecraft:end_crystal", output:"end_crystal"}, \
	{input:"minecraft:spore_blossom", output:"spore_blossom"}, \
	{input:"minecraft:pink_petals", output:"pink_petals"}, \
	{input:"minecraft:red_mushroom_block", output:"red_mushroom_block"}, \
	{input:"minecraft:brown_mushroom_block", output:"brown_mushroom_block"}, \
	{input:"minecraft:apple", output:"apple"}, \
	{input:"minecraft:fermented_spider_eye", output:"fermented_spider_eye"}, \
	{input:"minecraft:salmon", output:"salmon"}, \
	{input:"minecraft:cod", output:"cod"}, \
	{input:"minecraft:beetroot", output:"beetroot"}, \
	{input:"minecraft:brain_coral", output:"brain_coral"}, \
	{input:"minecraft:bubble_coral", output:"bubble_coral"}, \
	{input:"minecraft:dark_prismarine", output:"dark_prismarine"}, \
	{input:"minecraft:end_stone", output:"end_stone"}, \
	{input:"minecraft:experience_bottle", output:"experience_bottle"}, \
	{input:"minecraft:fire_coral", output:"fire_coral"}, \
	{input:"minecraft:honey_bottle", output:"honey_bottle"}, \
	{input:"minecraft:honeycomb", output:"honeycomb"}, \
	{input:"minecraft:horn_coral", output:"horn_coral"}, \
	{input:"minecraft:pointed_dripstone", output:"pointed_dripstone"}, \
	{input:"minecraft:raw_copper", output:"raw_copper"}, \
	{input:"minecraft:raw_gold", output:"raw_gold"}, \
	{input:"minecraft:raw_iron", output:"raw_iron"}, \
	{input:"minecraft:sculk_catalyst", output:"sculk_catalyst"}, \
	{input:"minecraft:soul_sand", output:"soul_sand"}, \
	{input:"minecraft:tube_coral", output:"tube_coral"}, \
	{input:"minecraft:wildflowers", output:"wildflowers"}, \
	{input:"minecraft:sniffer_egg", output:"sniffer_egg"}, \
	{input:"minecraft:pale_moss_block", output:"pale_moss_block"}, \
	{input:"minecraft:mycelium", output:"mycelium"}, \
	{input:"minecraft:podzol", output:"podzol"}, \
	{input:"minecraft:redstone_lamp", output:"redstone_lamp"}, \
	{input:"minecraft:sweet_berries", output:"sweet_berries"}, \
	{input:"minecraft:nether_wart", output:"nether_wart"}, \
	{input:"minecraft:crimson_fungus", output:"crimson_fungus"}, \
	{input:"minecraft:warped_fungus", output:"warped_fungus"}, \
	{input:"minecraft:amethyst_cluster", output:"amethyst_cluster"}, \
	{input:"minecraft:fire_charge", output:"fire_charge"}, \
	{input:"minecraft:brick", output:"brick"}, \
	{input:"minecraft:shelf_mushroom", output:"shelf_mushroom"}, \
	{input:"minecraft:pumpkin_pie", output:"pumpkin_pie"}, \
	{input:"minecraft:lily_pad", output:"lily_pad"}, \
	{input:"minecraft:sea_pickle", output:"sea_pickle"}, \
	{input:"minecraft:target", output:"target"}, \
	{input:"minecraft:phantom_membrane", output:"phantom_membrane"} \
]

data modify storage new_trims:trim_list armor.head set value [ \
	"minecraft:leather_helmet", \
	"minecraft:copper_helmet", \
	"minecraft:chainmail_helmet", \
	"minecraft:iron_helmet", \
	"minecraft:golden_helmet", \
	"minecraft:diamond_helmet", \
	"minecraft:netherite_helmet", \
	"minecraft:turtle_helmet" \
]

data modify storage new_trims:trim_list armor.chest set value [ \
	"minecraft:leather_chestplate", \
	"minecraft:copper_chestplate", \
	"minecraft:chainmail_chestplate", \
	"minecraft:iron_chestplate", \
	"minecraft:golden_chestplate", \
	"minecraft:diamond_chestplate", \
	"minecraft:netherite_chestplate" \
]

data modify storage new_trims:trim_list armor.legs set value [ \
	"minecraft:leather_leggings", \
	"minecraft:copper_leggings", \
	"minecraft:chainmail_leggings", \
	"minecraft:iron_leggings", \
	"minecraft:golden_leggings", \
	"minecraft:diamond_leggings", \
	"minecraft:netherite_leggings" \
]

data modify storage new_trims:trim_list armor.feet set value [ \
	"minecraft:leather_boots", \
	"minecraft:copper_boots", \
	"minecraft:chainmail_boots", \
	"minecraft:iron_boots", \
	"minecraft:golden_boots", \
	"minecraft:diamond_boots", \
	"minecraft:netherite_boots" \
]

data modify storage new_trims:trim_list patterns set value [ \
	"minecraft:sentry", \
	"minecraft:vex", \
	"minecraft:wild", \
	"minecraft:coast", \
	"minecraft:dune", \
	"minecraft:wayfinder", \
	"minecraft:raiser", \
	"minecraft:shaper", \
	"minecraft:host", \
	"minecraft:ward", \
	"minecraft:silence", \
	"minecraft:tide", \
	"minecraft:snout", \
	"minecraft:rib", \
	"minecraft:eye", \
	"minecraft:spire", \
	"minecraft:flow", \
	"minecraft:bolt" \
]

data modify storage new_trims:trim_list materials set value [ \
	"new_trims:white_dye", \
	"new_trims:light_gray_dye", \
	"new_trims:gray_dye", \
	"new_trims:black_dye", \
	"new_trims:brown_dye", \
	"new_trims:red_dye", \
	"new_trims:orange_dye", \
	"new_trims:yellow_dye", \
	"new_trims:lime_dye", \
	"new_trims:green_dye", \
	"new_trims:cyan_dye", \
	"new_trims:light_blue_dye", \
	"new_trims:blue_dye", \
	"new_trims:purple_dye", \
	"new_trims:magenta_dye", \
	"new_trims:pink_dye", \
	"new_trims:sugar", \
	"new_trims:bone_block", \
	"new_trims:quartz", \
	"new_trims:nether_star", \
	"new_trims:clay", \
	"new_trims:iron", \
	"new_trims:gunpowder", \
	"new_trims:heavy_core", \
	"new_trims:coal", \
	"new_trims:netherite", \
	"new_trims:nether_brick", \
	"new_trims:netherite_scrap", \
	"new_trims:brown_mushroom_block", \
	"new_trims:salmon", \
	"new_trims:tnt", \
	"new_trims:red_mushroom_block", \
	"new_trims:apple", \
	"new_trims:nether_wart_block", \
	"new_trims:redstone", \
	"new_trims:fermented_spider_eye", \
	"new_trims:copper", \
	"new_trims:leather", \
	"new_trims:magma", \
	"new_trims:resin", \
	"new_trims:shroomlight", \
	"new_trims:pumpkin", \
	"new_trims:blaze_rod", \
	"new_trims:gold", \
	"new_trims:glowstone_dust", \
	"new_trims:cod", \
	"new_trims:ochre_froglight", \
	"new_trims:verdant_froglight", \
	"new_trims:slime_ball", \
	"new_trims:melon", \
	"new_trims:moss_block", \
	"new_trims:turtle_scute", \
	"new_trims:emerald", \
	"new_trims:dried_kelp_block", \
	"new_trims:ender_eye", \
	"new_trims:sculk", \
	"new_trims:echo_shard", \
	"new_trims:heart_of_the_sea", \
	"new_trims:warped_wart_block", \
	"new_trims:ender_pearl", \
	"new_trims:diamond", \
	"new_trims:prismarine_shard", \
	"new_trims:ghast_tear", \
	"new_trims:prismarine_crystals", \
	"new_trims:blue_ice", \
	"new_trims:breeze_rod", \
	"new_trims:lapis", \
	"new_trims:obsidian", \
	"new_trims:crying_obsidian", \
	"new_trims:amethyst", \
	"new_trims:end_crystal", \
	"new_trims:chorus_flower", \
	"new_trims:shulker_shell", \
	"new_trims:popped_chorus_fruit", \
	"new_trims:pearlescent_froglight", \
	"new_trims:dragon_breath", \
	"new_trims:spore_blossom", \
	"new_trims:pink_petals", \
	"new_trims:cactus_flower", \
	"new_trims:armadillo_scute", \
	"new_trims:melon_slice", \
	"new_trims:nautilus_shell", \
	"new_trims:creeper_head", \
	"new_trims:pufferfish", \
	"new_trims:torchflower", \
	"new_trims:cake", \
	"new_trims:tropical_fish", \
	"new_trims:pitcher_plant", \
	"new_trims:creaking_heart", \
	"new_trims:glow_berries", \
	"new_trims:beetroot", \
	"new_trims:brain_coral", \
	"new_trims:bubble_coral", \
	"new_trims:dark_prismarine", \
	"new_trims:end_stone", \
	"new_trims:experience_bottle", \
	"new_trims:fire_coral", \
	"new_trims:honey_bottle", \
	"new_trims:honeycomb", \
	"new_trims:horn_coral", \
	"new_trims:pointed_dripstone", \
	"new_trims:raw_copper", \
	"new_trims:raw_gold", \
	"new_trims:raw_iron", \
	"new_trims:sculk_catalyst", \
	"new_trims:soul_sand", \
	"new_trims:tube_coral", \
	"new_trims:wildflowers", \
	"new_trims:sniffer_egg", \
	"new_trims:pale_moss_block", \
	"new_trims:mycelium", \
	"new_trims:podzol", \
	"new_trims:redstone_lamp", \
	"new_trims:sweet_berries", \
	"new_trims:nether_wart", \
	"new_trims:crimson_fungus", \
	"new_trims:warped_fungus", \
	"new_trims:amethyst_cluster", \
	"new_trims:fire_charge", \
	"new_trims:brick", \
	"new_trims:shelf_mushroom", \
	"new_trims:pumpkin_pie", \
	"new_trims:lily_pad", \
	"new_trims:sea_pickle", \
	"new_trims:target", \
	"new_trims:phantom_membrane" \
]


scoreboard objectives add trim_slot dummy

