
function new_trims:check_inventory_materials

