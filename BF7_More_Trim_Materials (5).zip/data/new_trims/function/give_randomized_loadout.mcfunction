
execute store result storage new_trims:armor_random helmet_type int 1 run random value 0..7
execute store result storage new_trims:armor_random helmet_pattern int 1 run random value 0..17
execute store result storage new_trims:armor_random helmet_material int 1 run random value 0..89

execute store result storage new_trims:armor_random chestplate_type int 1 run random value 0..6
execute store result storage new_trims:armor_random chestplate_pattern int 1 run random value 0..17
execute store result storage new_trims:armor_random chestplate_material int 1 run random value 0..89

execute store result storage new_trims:armor_random leggings_type int 1 run random value 0..6
execute store result storage new_trims:armor_random leggings_pattern int 1 run random value 0..17
execute store result storage new_trims:armor_random leggings_material int 1 run random value 0..89

execute store result storage new_trims:armor_random boots_type int 1 run random value 0..6
execute store result storage new_trims:armor_random boots_pattern int 1 run random value 0..17
execute store result storage new_trims:armor_random boots_material int 1 run random value 0..89

function new_trims:find_armor with storage new_trims:armor_random

