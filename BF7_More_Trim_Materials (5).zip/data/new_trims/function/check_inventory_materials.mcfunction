
execute as @a if items entity @s container.* #new_trims:new_trim_materials[!custom_data~{trimable:true}] run function new_trims:prepare_inventory_trimable_item
execute as @e[type=item,tag=!trim_item_checked] if items entity @s contents #new_trims:new_trim_materials[!custom_data~{trimable:true}] run function new_trims:prepare_trim_item
tag @e[type=item,tag=!trim_item_checked] add trim_item_checked
